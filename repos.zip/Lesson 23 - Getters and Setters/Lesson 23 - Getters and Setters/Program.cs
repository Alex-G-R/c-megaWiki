﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_23___Getters_and_Setters
{
    class Program
    {
        static void Main(string[] args)
        {
            Movie avengers = new Movie("Avengers", "Johs Whedon", "Pegi-13");
            Movie shrek = new Movie("Shrek", "Osioł", "Pegi-21");


            Console.ReadLine();
        }
    }
}

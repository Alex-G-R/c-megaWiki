﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_20___Classes_and_Objects
{
    class Book
    {
        public string title;
        public string author;
        public int pages;
        public double price;
    }
}

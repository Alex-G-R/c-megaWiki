﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_types
{
    class Program
    {
        static void Main(string[] args)
        {
            string fraza = "Kochama C#";
            char literka = 'A';
            // Literka w Char trzeba zapisać w 'x' a nie w "x"


            int liczba = 69;
            double liczbaZprzecinkiem = 3.7;

            bool jestKobieta = false;

            
        }
    }
}

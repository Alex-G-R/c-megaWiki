﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_25___Static_Methods_and_Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Math.Sqrt(144));

            UsefulTools.SayHi("Alex");

            Console.ReadLine();
        }

    }
}
